Yahoo Finance 收盘价抓取脚本 v8（PowerShell 专版）
-------------------------------------------------------
✅ 完全使用 PowerShell，避免 .bat 编码乱码、兼容性问题
✅ 无需 API Key，可抓取所有美股
✅ 输出为 JSON 格式，字段包含日期与收盘价

【使用方法】
1. 打开 PowerShell（Win + R → 输入 powershell）
2. 输入以下命令（进入目录）：
   cd D:\fetch_yahoo_v8
3. 输入以下命令运行脚本：
   .\fetch_prices.ps1
4. 运行后将生成 data\AAPL_daily.json 等文件

如遇权限限制，请先运行：
   Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
然后按 Y 确认
