$symbols = Get-Content .\symbols.txt | Where-Object { $_.Trim() -ne "" }
$outdir = "data"
if (-not (Test-Path $outdir)) { mkdir $outdir | Out-Null }

$start = [int][double]::Parse((Get-Date "$((Get-Date).Year)-01-01" -UFormat %s))
$end   = [int][double]::Parse((Get-Date -UFormat %s))

foreach ($sym in $symbols) {
    Write-Host "正在抓取 $sym ..."
    $url = "https://query1.finance.yahoo.com/v7/finance/download/$sym?period1=$start&period2=$end&interval=1d&events=history"
    $csvFile = "$outdir\$sym.csv"
    $jsonFile = "$outdir\${sym}_daily.json"

    try {
        Invoke-WebRequest -Uri $url -OutFile $csvFile -UseBasicParsing -ErrorAction Stop
        $lines = Get-Content $csvFile | Where-Object { $_ -notmatch '^Date' -and $_ -ne "" }
        $out = @{}
        foreach ($line in $lines) {
            $p = $line -split ','
            if ($p.Length -ge 5) {
                $out[$p[0]] = @{ close = $p[4] }
            }
        }
        $out | ConvertTo-Json -Depth 3 | Out-File $jsonFile -Encoding utf8
        Write-Host "✅ $sym 完成"
    } catch {
        Write-Host "❌ $sym 下载失败：$($_.Exception.Message)"
    }
}

Write-Host "`n全部完成。"
